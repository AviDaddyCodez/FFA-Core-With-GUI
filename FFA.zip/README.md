# FFA-Core
Plugin with more than one FreeForAll modality in a single plugin

# Download(s)
FFA-Core for PocketMine-MP Servers: https://github.com/RxDuZ/FFA-Core

## Config
What you can edit:
* You can edit the Scoreboards colors
* Implement the IP address of your server
* Change item type and name when entering spectator mode



