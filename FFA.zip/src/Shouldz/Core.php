<?php

/*
* Core FFA made by: Loggy (RxDuZ)
* Twitter: @LOGGY GAMER4794 
* Discord: https://discord.gg/c3FXHYvtTd
*/

namespace Shouldz;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\entity\Entity;
use pocketmine\utils\TextFormat as Color;

use Shouldz\Execute\Commands;
use Shouldz\Events\EventListener;
use Shouldz\utils\{KD, Entities\JoinCore, Entities\CoreStatus, ScoreAPI\ScoreAPI};
use Shouldz\Task\{GameTask, EntityTask};
use Shouldz\Arena\{Arena, ArenaCreator};

class Core extends PluginBase implements Listener {
	
	private $data = [];
	
	private static $creator = null;
	
	private static $arena = null;
	
	private static $score = null;
	
	private static $kd = null;
	
	public function onLoad(){
		
		$logger = $this->getServer()->getLogger();
		
		$this->data["prefix"] = Color::DARK_GRAY . "[" . Color::BLUE . "FFA" . Color::DARK_GRAY . "]" . Color::RESET . " ";
		
		$logger->info($this->getPrefix() . Color::GOLD . "Loading...");
		
		Core::$creator = new ArenaCreator($this);
	
	    Core::$arena = new Arena($this);
	
	    Core::$score = new ScoreAPI($this);
	
	    Core::$kd = new KD($this);
		
	}
	
	public function onEnable(){
		
		$logger = $this->getServer()->getLogger();
		
		$logger->info($this->getPrefix() . Color::GOLD . "Enabled made by: ShouldzZ");
		
		$this->getServer()->getCommandMap()->register("core", new Commands($this));
		
		$this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);
		
		$this->getScheduler()->scheduleRepeatingTask(new GameTask($this), 20);
		
		new EntityTask($this);
		
		Entity::registerEntity(JoinCore::class, true);
		
		Entity::registerEntity(CoreStatus::class, true);
		
		@mkdir($this->getDataFolder());
		
		@mkdir($this->getDataFolder() . "players/");
		
		@mkdir($this->getDataFolder() . "data/");
		
		$this->saveResource("/settings.yml");
		
	}
	
	public function getPrefix() {
		return $this->data["prefix"];
	}
	
	public static function getCreator() : ArenaCreator {
		return Core::$creator;
	}
	
	public static function getArena() : Arena {
		return Core::$arena;
	}
	
	public static function getScore() : ScoreAPI {
		return Core::$score;
	}
	
	public static function getKD() : KD {
		return Core::$kd;
	}
	
}

?>