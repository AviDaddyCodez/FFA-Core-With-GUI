<?php

namespace Shouldz\Events;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\event\block\{BlockBreakEvent, BlockPlaceEvent};
use pocketmine\event\entity\{EntityDamageEvent, EntityDamageByEntityEvent, EntityLevelChangeEvent};
use pocketmine\event\player\{PlayerDeathEvent, PlayerRespawnEvent, PlayerDropItemEvent, PlayerExhaustEvent, PlayerItemHeldEvent};
use pocketmine\utils\TextFormat as Color;

use Shouldz\utils\Entities\{JoinCore, CoreStatus};
use Shouldz\Core;

class EventListener implements Listener {
	
	public $listener;
	
	public function __construct(Core $listener){
		$this->listener = $listener;
		
	}
	
	public function getListener(){
		return $this->listener;
	}
	
	public function onBreak(BlockBreakEvent $ev){
		$player = $ev->getPlayer();
		if($player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getGappleArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getComboArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getDebuffArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getFistArena())){
			$ev->setCancelled(true);
			$player->sendPopup($this->getListener()->getPrefix() . Color::RED . "You can't break right now");
		}
	}
	
	public function onPlace(BlockPlaceEvent $ev){
		$player = $ev->getPlayer();
		if($player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getGappleArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getComboArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getDebuffArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getFistArena())){
			$ev->setCancelled(true);
			$player->sendPopup($this->getListener()->getPrefix() . Color::RED . "You can't build right now");
		}
	}
	
	public function onDrop(PlayerDropItemEvent $ev){
		$player = $ev->getPlayer();
		if($player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getGappleArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getComboArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getDebuffArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getFistArena())){
			$ev->setCancelled(true);
		}
	}
	
	public function onChange(EntityLevelChangeEvent $ev){
		$player = $ev->getEntity();
		if($player instanceof Player){
			if($player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getGappleArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getComboArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getDebuffArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getFistArena())){
				$player->setMaxHealth(20);
                $player->setHealth(20);
                $score = Core::getScore();
                $score->remove($player);
                
			}
		}
	}
	
	public function onDamageFall(EntityDamageEvent $ev){
		$player = $ev->getEntity();
		if($player instanceof Player){
			if($player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getGappleArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getComboArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getDebuffArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getFistArena())){
				if($ev->getCause() === EntityDamageEvent::CAUSE_FALL){
					$ev->setCancelled(true);
				}
			}
		}
	}
	
	public function onExhaust(PlayerExhaustEvent $ev){
		$player = $ev->getPlayer();
		if($player instanceof Player){
			if($player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getGappleArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getComboArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getDebuffArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getFistArena())){
				$ev->setCancelled(true);
			}
		}
	}
	
	public function onDeath(PlayerDeathEvent $ev){
		$player = $ev->getPlayer();
		if($player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getGappleArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getComboArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getDebuffArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getFistArena())){
			$ev->setDrops([]);
			$ev->setDeathMessage("");
			$cause = $ev->getEntity()->getLastDamageCause();
			if($cause instanceof EntityDamageByEntityEvent){
				$damager = $cause->getDamager();
				if($damager instanceof Player){
					Core::getKD()->addDeath($player);
					foreach ($damager->getLevel()->getPlayers() as $players){
						$players->sendMessage($this->getListener()->getPrefix() . Color::RED . $player->getName() . Color::GRAY . " was killed by " . Color::GREEN . $damager->getName());
						Core::getArena()->playSound($players, 'mob.ghast.charge');
					}
					Core::getKD()->addKill($damager);
					Core::getArena()->getReKit($damager);
					$damager->setHealth($damager->getMaxHealth());
				}
			}
		}
	}
	
	public function onRespawn(PlayerRespawnEvent $ev){
		$player = $ev->getPlayer();
		if($player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getGappleArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getComboArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getDebuffArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getFistArena())){
			$ev->setRespawnPosition(Server::getInstance()->getLevelByName($player->getLevel()->getFolderName())->getSafeSpawn());
			Core::getKD()->sendSpectator($player);
		}
	}
	
	public function onFunction(EntityDamageByEntityEvent $ev){
		$npc = $ev->getEntity();
		$player = $ev->getDamager();
		if($npc instanceof JoinCore && $player instanceof Player){
			$ev->setCancelled(true);
			Core::getArena()->getForm($player);
		} else if($npc instanceof CoreStatus && $player instanceof Player){
			$ev->setCancelled(true);
			Core::getKD()->getStatus($player);
		}
	}
	
	public function setKnockback(EntityDamageByEntityEvent $ev){
		$player = $ev->getEntity();
		$damager = $ev->getDamager();
		$kb = Core::getCreator()->getKB();
		$dl = Core::getCreator()->getDL();
		if($ev instanceof EntityDamageByEntityEvent){
			if($player instanceof Player && $damager instanceof Player){
				if($player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getGappleArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getDebuffArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getFistArena())){
					$ev->setKnockBack($kb);
					$ev->setAttackCooldown($dl);
				}
			}
		}
	}
	
	public function setKnockbackCombo(EntityDamageByEntityEvent $ev){
		$player = $ev->getEntity();
		$damager = $ev->getDamager();
		if($ev instanceof EntityDamageByEntityEvent){
			if($player instanceof Player && $damager instanceof Player){
				if($damager->getGamemode() == 0){
					if($player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getComboArena())){
						$ev->setKnockBack(0.25);
						$ev->setCancelled(false);
					}
				}
			}
		}
	}
	
	public function onHeld(PlayerItemHeldEvent $ev){
		$player = $ev->getPlayer();
		$item = $ev->getItem()->getCustomName();
		if($player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getGappleArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getComboArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getDebuffArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getFistArena())){
			if($player->getGamemode() == 3){
				if($item == Core::getCreator()->getItemName()){
					Core::getKD()->getFormRespawn($player);
				}
			}
		}
	}
	
}


?>