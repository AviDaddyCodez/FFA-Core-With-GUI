<?php

namespace Shouldz\Task;

use pocketmine\Player;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\utils\{Config, TextFormat as Color};

use Shouldz\Core;

class GameTask extends Task {
	
	private $task;
	
	public function __construct(Core $task){
		$this->task = $task;
		
	}
	
	public function getTask(){
		return $this->task;
	}
	
	public function getColorTitle(){
		$settings = new Config($this->getTask()->getDataFolder()."/settings.yml", Config::YAML);
		return $settings->get("color-title");
	}
	
	public function getColorLeft(){
		$settings = new Config($this->getTask()->getDataFolder()."/settings.yml", Config::YAML);
		return $settings->get("color-left");
	}
	
	public function getColorRight(){
		$settings = new Config($this->getTask()->getDataFolder()."/settings.yml", Config::YAML);
		return $settings->get("color-right");
	}
	
	public function getAddress(){
		$settings = new Config($this->getTask()->getDataFolder()."/settings.yml", Config::YAML);
		return $settings->get("server-address");
	}
	
	public function getPlayerPing(Player $player){
		$ping = $player->getPing();
		if($ping <= 80){
            return Color::GREEN . "■ " . $ping;
            
	    } else if($ping > 80 and $ping < 149){
            return Color::GOLD . "■ " . $ping;
            
	    }else if($ping >= 150 and $ping < 299){
            return Color::RED . "■ " . $ping;
            
	    } else if($ping >= 300){
            return Color::DARK_RED . "■ " . $ping;
            
        }
	}
	
	
	
	public function onRun(int $currenTick){
		foreach (Server::getInstance()->getOnlinePlayers() as $player){
			if($player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getGappleArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getComboArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getDebuffArena()) || $player->getLevel() == Server::getInstance()->getLevelByName(Core::getCreator()->getFistArena())){
				$score = Core::getScore();
				$score->new($player, $player->getName(), " " . self::getColorTitle() . "FFA");
				$score->setLine($player, 1, Color::RED);
				$score->setLine($player, 2, " " . self::getColorLeft() . "Players: " . self::getColorRight() . Core::getKD()->getKills($player));
				$score->setLine($player, 3, Color::GREEN);
				$score->setLine($player, 4, " " . self::getColorLeft() . "Mode: " . self::getColorRight() . Core::getArena()->getMode($player));
				$score->setLine($player, 5, Color::YELLOW);
				$score->setLine($player, 6, " " . self::getColorLeft() . "Kills: " . self::getColorRight() . Core::getKD()->getKills($player));
				$score->setLine($player, 7, " " . self::getColorLeft() . "Ping: " . self::getPlayerPing($player));
				$score->setLine($player, 8, Color::GOLD);
				$score->setLine($player, 9, " " . self::getAddress() . " ");
			}
		}
	}
	
}

?>