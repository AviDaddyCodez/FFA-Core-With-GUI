<?php

namespace Shouldz\utils;

class Permissions {
	
	const CORE_ADMIN = "core.command.admin";
	
}

?>