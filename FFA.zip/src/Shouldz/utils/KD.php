<?php

namespace Shouldz\utils;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\item\Item;
use pocketmine\utils\{Config, TextFormat as Color};

use Shouldz\utils\FormAPI\SimpleForm;
use Shouldz\Core;

class KD {
	
	private $kd;
	
	public function __construct(Core $kd){
		$this->kd = $kd;
	}
	
	public function addKill(Player $player){
		$data = new Config ($this->kd->getDataFolder()."players/kills.yml", Config::YAML);
		$data->set($player->getName(), $data->get($player->getName()) + 1);
		$data->save();
	}
	
	public function addDeath(Player $player){
		$data = new Config ($this->kd->getDataFolder()."players/deaths.yml", Config::YAML);
		$data->set($player->getName(), $data->get($player->getName()) + 1);
		$data->save();
	}
	
	public function getKills(Player $player){
		$data = new Config ($this->kd->getDataFolder()."players/kills.yml", Config::YAML);
		if($data->get($player->getName()) != null){
		    return $data->get($player->getName());
		} else {
			return 0;
		}
	}
	
	public function getDeaths(Player $player){
		$data = new Config ($this->kd->getDataFolder()."players/deaths.yml", Config::YAML);
		if($data->get($player->getName()) != null){
		    return $data->get($player->getName());
		} else {
			return 0;
		}
	}
	
	public function sendSpectator(Player $player){
		$cfg = new Config ($this->kd->getDataFolder()."/settings.yml", Config::YAML);
		$player->setGamemode(Player::VIEW);
		$player->addTitle(Color::BOLD . Color::RED . "YOU DEATH",Color::RESET . Color::GRAY . "You are a spectator");
		$id = explode(':', $cfg->get('item-id'));
        $player->getInventory()->setItem($cfg->get('item-slot'), Item::get($id[0] ?? 1, $id[1] ?? 0, 1)->setCustomName(Core::getCreator()->getItemName()));
	}
	
	public function getStatus(Player $player){
		$form = new SimpleForm(function (Player $player, int $data = null){
			$result = $data;
			if($data === null){
				return true;
				
			}
			
			switch ($result){
				case 0:
				// Closed
				break;
			}
			
		});
		
		$form->setTitle(Color::BOLD . Color::YELLOW . "FreeForAll Status");
		$form->setContent(Color::GREEN . "Kills: " . Color::WHITE . self::getKills($player) . "\n" . Color::GREEN . "Deaths: " . Color::WHITE . self::getDeaths($player) . "\n");
		$form->addButton(Color::GREEN . "Ok");
		$form->sendToPlayer($player);
		return $form;
		
	}
	
	public function getFormRespawn(Player $player){
		$form = new SimpleForm(function (Player $player, int $data = null){
			$result = $data;
			if($data === null){
				return true;
				
			}
			
			switch ($result){
				case 0:
				Core::getArena()->getRespawn($player);
				break;
				case 1:
				$player->teleport(Server::getInstance()->getDefaultLevel()->getSafeSpawn());
				$player->setGamemode(Player::SURVIVAL);
				$player->getInventory()->clearAll();
				$player->getArmorInventory()->clearAll();
				break;
				default:
				return;
			}
			
		});
		
		$form->setTitle(Color::BOLD . Color::YELLOW . "FreeForAll Teleport");
		$form->setContent(Color::WHITE . "¿Where do you want to go?" . "\n");
		$form->addButton(Color::GREEN . "Respawn");
		$form->addButton(Color::GREEN . "Back to the Lobby");
		$form->sendToPlayer($player);
		return $form;
		
	}
	
}

?>