<?php

namespace Shouldz\utils\Entities;


use pocketmine\entity\Human;

class JoinCore extends Human {
	public function getName(): string {
		return '';
	}
}